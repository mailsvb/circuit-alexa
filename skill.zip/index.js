const Alexa   = require('alexa-sdk');
const Circuit = require('circuit-api-sdk');
let con = new Circuit({server:'eu.yourcircuit.com',cookie:'connect.sess='});

const APP_ID = ''; // TODO replace with your app ID (OPTIONAL).

const languageStrings = {
    'en-GB': {
        translation: {
            WELCOME: "Welcome to Circuit",
            SKILL_NAME: "Circuit by Unify",
            GET_MY_MESSAGE: "Here are your latest messages",
            UNREAD_START: "You have",
            UNREAD_NONE: "no",
            UNREAD_SINGLE: "one",
            UNREAD_END_NONE: "unread messages",
            UNREAD_END_SINGLE: "unread message",
            UNREAD_END: "unread messages",
            HELP_MESSAGE: "You can say, read my latest messages, or, you can say, do I have unread messages... What can I help you with?",
            HELP_REPROMPT: "What can I do for you?",
            STOP_MESSAGE: "Goodbye!",
            MORE: "Is there anything else I can do for you?",
            MSG_IN_YOUR_WITH: "In your conversation with",
            MSG_IN_YOUR_OPEN: "In a Community",
            MSG_IN_YOUR_GROUP: "In a group conversation",
        },
    },
    'en-US': {
        translation: {
            WELCOME: "Welcome to Circuit",
            SKILL_NAME: "Circuit by Unify",
            GET_MY_MESSAGE: "Here are your latest messages",
            UNREAD_START: "You have",
            UNREAD_NONE: "no",
            UNREAD_SINGLE: "one",
            UNREAD_END_NONE: "unread messages",
            UNREAD_END_SINGLE: "unread message",
            UNREAD_END: "unread messages",
            HELP_MESSAGE: "You can say, read my latest messages, or, you can say, do I have unread messages... What can I help you with?",
            HELP_REPROMPT: "What can I do for you?",
            STOP_MESSAGE: "Goodbye!",
            MORE: "Is there anything else I can do for you?",
            MSG_IN_YOUR_WITH: "In your conversation with",
            MSG_IN_YOUR_OPEN: "In a Community",
            MSG_IN_YOUR_GROUP: "In a group conversation",
        },
    },
    'de-DE': {
        translation: {
            WELCOME: "Willkommen bei Circuit",
            SKILL_NAME: "Circuit by Unify",
            GET_MY_MESSAGE: "Hier sind Deine letzten Nachrichten: ",
            UNREAD_START: "Du hast",
            UNREAD_NONE: "keine",
            UNREAD_SINGLE: "eine",
            UNREAD_END_NONE: "ungelesenen Nachrichten",
            UNREAD_END_SINGLE: "ungelesene Nachricht",
            UNREAD_END: "ungelesene Nachrichten",
            HELP_MESSAGE: "Du kannst sagen, Lies mir meine letzten Nachrichten vor, oder du kannst, Habe ich ungelesene Nachrichten, sagen... Was kann ich fuer Dich tun?",
            HELP_REPROMPT: "Was kann ich fuer Dich tun?",
            STOP_MESSAGE: "Auf Wiedersehen!",
            MORE: "Kann ich sonst noch was fuer Dich tun?",
            MSG_IN_YOUR_WITH: "In Deiner Konversation mit",
            MSG_IN_YOUR_OPEN: "In einer Community",
            MSG_IN_YOUR_GROUP: "In einer Gruppenkonversation",
        },
    },
};

const handlers = {
    'LaunchRequest': function () {
      const _self = this;
      con.login()
      .then(user => {
        let hello = _self.t('WELCOME') + '<break time="200ms"/>' + user.firstName + '<break time="200ms"/>' +  _self.t('HELP_REPROMPT');
        _self.emit(':ask', hello, hello);
        con.exit();
      })
      .catch(err => {
        console.error(err);
        con.exit();
      });
    },
    'GetLatestMessages': function () {
      const _self = this;
      con.login()
      .then(user => {
        _self.user = user;
        con.getMarkedConversations()
        .then(res => {
          let muted = [];
          if (res.mutedConvIds) {
              muted = res.mutedConvIds;
          }
          con.getConversations()
          .then(res => {
            let max = 3;
            let user = [];
            user.push(_self.user.userId);
            let conv = [];
            if (res instanceof Object && res.conversations instanceof Array) {
              res.conversations.reverse();
              for (let i=0; i<res.conversations.length && max > 0; i++) {
                if (muted.indexOf(res.conversations[i].convId) < 0 && res.conversations[i].topLevelItem.type == 'TEXT') {
                  max--;
                  if (res.conversations[i].topLevelItem.creatorId != _self.user.userId) {
                    user.push(res.conversations[i].topLevelItem.creatorId);
                  }
                  if (!(res.conversations[i].topic && res.conversations[i].topic != '') &&
                      !(res.conversations[i].topicPlaceholder && res.conversations[i].topicPlaceholder != '') &&
                       res.conversations[i].participants.length < 5)
                  {
                    for (let j=0; j<res.conversations[i].participants.length; j++) {
                      if (res.conversations[i].participants[j].userId != _self.user.userId) {
                        user.push(res.conversations[i].participants[j].userId);
                      }
                    }
                  }
                  else {
                    res.conversations[i].participants = null;
                  }
                  conv.push(res.conversations[i]);
                }
              }
              let userpromise = con.getUsersByIds(user);
              Promise.all([userpromise])
                .then(([user]) => {
                  let userNames = {};
                  for (let i=0; i < user.length; i++) {
                      userNames[user[i].userId] = user[i].displayName;
                  }
                  let text = '';
                  for (let i=0; i < conv.length; i++) {
                    if (conv[i].type == 'OPEN' || conv[i].type == 'GROUP') {
                      if (conv[i].topic && conv[i].topic != '') {
                        text += "In " + conv[i].topic;
                      }
                      else if (conv[i].topicPlaceholder && conv[i].topicPlaceholder != '') {
                        text += "In " + conv[i].topicPlaceholder;
                      }
                      else if (conv[i].participants && conv[i].participants.length > 0) {
                        text += _self.t('MSG_IN_YOUR_WITH');
                        for (let j=0; j < conv[i].participants.length; j++) {
                          if (conv[i].participants[j].userId != _self.user.userId) {
                            text += '<break time="250ms"/>' + userNames[conv[i].participants[j].userId];
                          }
                        }
                      }
                      else {
                        text += _self.t('MSG_IN_YOUR_' + conv[i].type);
                      }
                    }
                    else {
                      let directName;
                      for (let j=0; j < conv[i].participants.length; j++) {
                        if (conv[i].participants[j].userId != _self.user.userId) {
                          directName = conv[i].participants[j].userId;
                        }
                      }
                      text += _self.t('MSG_IN_YOUR_WITH') + '<break time="250ms"/>' + userNames[directName];
                    }
                    text += '<break time="250ms"/>from ' + userNames[conv[i].topLevelItem.creatorId];
                    text += '<break time="250ms"/>' + conv[i].topLevelItem.text.content.replace(/<[^>]*>/g, '')
                                                                                       .replace(/&#[^;]*;/g, '')
                                                                                       .replace(/[\r\n]{1,2}/g, ' ')
                                                                                       .replace(/[\t]{1,}/g, ' ')
                                                                                       .replace(/[\s]{2,}/g, ' ');
                    text += '<break time="500ms"/>';
                  }
                  _self.emit(':tellWithCard', text, _self.t('SKILL_NAME'), 'Deine Nachrichten');
                  con.exit();
                })
                .catch(err => {
                  console.error(err);
                  con.exit();
                });
            }
          })
          .catch(err => {
              console.error(err);
              con.exit();
          });
        })
        .catch(err => {
          console.error(err);
          con.exit();
        });
      })
      .catch(err => {
        console.error(err);
        con.exit();
      });
    },
    'GetUnread': function () {
      const _self = this;
      con.login()
      .then(user => {
        con.getMarkedConversations()
        .then(res => {
          let muted = [];
          if (res.mutedConvIds) {
              muted = res.mutedConvIds;
          }
          con.getConversations(new Date().getTime(), 'BEFORE', '50')
          .then(res => {
            if (res instanceof Object && res.conversations instanceof Array) {
              let unreadCount = 0;
              for (let i=0; i<res.conversations.length; i++) {
                if (res.conversations[i].userData instanceof Object && res.conversations[i].userData.unreadItems && muted.indexOf(res.conversations[i].convId) < 0) {
                  unreadCount += parseInt(res.conversations[i].userData.unreadItems);
                }
              }
              let unread = _self.t('UNREAD_START') + '<break time="250ms"/>';
              if (unreadCount == 0) {
                unread += _self.t('UNREAD_NONE') + '<break time="250ms"/>' + _self.t('UNREAD_END_NONE');
              }
              else if (unreadCount == 1) {
                unread += _self.t('UNREAD_SINGLE') + '<break time="250ms"/>' + _self.t('UNREAD_END_SINGLE');
              }
              else {
                unread += unreadCount + '<break time="250ms"/>' + _self.t('UNREAD_END');
              }
              _self.emit(':tellWithCard', unread, _self.t('SKILL_NAME'), 'Deine ungelesenen Nachrichten');
              con.exit();
            }
          })
          .catch(err => {
            console.error(err);
            con.exit();
          });
        })
        .catch(err => {
          console.error(err);
          con.exit();
        });
      })
      .catch(err => {
        console.error(err);
        con.exit();
      });
    },
    'GetMentions': function () {
      const _self = this;
      con.login()
      .then(user => {
        con.getUserActivities('20')
        .then(res => {
          if (parseInt(res.totalUnreadActivities) > 0 && res.activityItems instanceof Array && res.activityItems.length > 0) {
            let user = [];
            let conv = [];
            let match = [];
            for (let i=0; i < res.activityItems.length; i++) {
              if (res.activityItems[i].isRead == false) {
                user.push(res.activityItems[i].creatorId);
                conv.push(res.activityItems[i].navigableItem.mention.itemReference.convId);
                match.push(res.activityItems[i]);
              }
            }
            let userpromise = con.getUsersByIds(user);
            Promise.all([userpromise])
              .then(([user]) => {
                let userNames = {};
                for (let i=0; i < user.length; i++) {
                  userNames[user[i].userId] = user[i].displayName;
                }
                let message = "Du hast " + res.totalUnreadActivities + " ungelesene Erwähnungen von";
                for (let i=0; i < res.activityItems.length; i++) {
                  if (res.activityItems[i].isRead == false) {
                    message+='<break time="250ms"/>' + userNames[res.activityItems[i].creatorId];
                  }
                }
                _self.emit(':tellWithCard', message, _self.t('SKILL_NAME'), 'Deine ungelesenen Erwähnungen');
                con.exit();
              })
              .catch(err => {
                console.error(err);
                con.exit();
              });
          }
          else {
            _self.emit(':tellWithCard', "Du hast keine ungelesenen Erwähnungen", _self.t('SKILL_NAME'), 'Deine ungelesenen Erwähnungen');
            con.exit();
          }
        })
        .catch(err => {
          console.error(err);
          con.exit();
        });
      })
      .catch(err => {
        console.error(err);
        con.exit();
      });
    },
    'AMAZON.HelpIntent': function () {
        const speechOutput = this.t('HELP_MESSAGE');
        const reprompt = this.t('HELP_MESSAGE');
        this.emit(':ask', speechOutput, reprompt);
    },
    'AMAZON.CancelIntent': function () {
        this.emit(':tell', this.t('STOP_MESSAGE'));
    },
    'AMAZON.StopIntent': function () {
        this.emit(':tell', this.t('STOP_MESSAGE'));
    },
    'SessionEndedRequest': function () {
        this.emit(':tell', this.t('STOP_MESSAGE'));
    },
};

exports.handler = (event, context) => {
    const alexa = Alexa.handler(event, context);
    alexa.APP_ID = APP_ID;
    // To enable string internationalization (i18n) features, set a resources object.
    alexa.resources = languageStrings;
    alexa.registerHandlers(handlers);
    alexa.execute();
};
